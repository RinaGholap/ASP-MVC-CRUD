﻿using NurseryManagementMVC_CRUD.CustomFilter;
using NurseryManagementMVC_CRUD.Filter;
using NurseryManagementMVC_CRUD.Models;
using System.Linq;
using System.Web.Mvc;

namespace Final_Assignment_Rina_Gholap.Controllers
{
    [CustomAuthorizationFilter]
    [UserAuthorizationFilter(AllowedRole = "Admin")]
    public class FlowerController : Controller
    {
        // GET: Flower
        public ActionResult Index()
        {
            NurseryManagementEntities flowerDBContext = new NurseryManagementEntities();
            var flowersList = flowerDBContext.FlowerDetails.ToList();
            ViewBag.TotalFlowers = flowersList.Count;
            return View(flowersList);
        }

        public ActionResult Create()
        {
            TempData["Title"] = "Add";
            return View("AddEdit");
        }

        [HttpPost]
        public ActionResult Create(FlowerDetail flowerData)
        {
            if (ModelState.IsValid)
            {
                NurseryManagementEntities flowerDBContext = new NurseryManagementEntities();
                // Get the latest FlowerId from the database
                var latestFlower = flowerDBContext.FlowerDetails.OrderByDescending(f => f.FlowerId).FirstOrDefault();
                if (latestFlower != null)
                {
                    // Extract the numeric part of the latest FlowerId and increment it
                    int latestIdNumericPart = int.Parse(latestFlower.FlowerId.Substring(7));
                    flowerData.FlowerId = "FID_" + (latestIdNumericPart + 1).ToString("D5"); // Pad with leading zeros
                }
                else
                {   // If there are no existing records, start with "FID_00001"
                    flowerData.FlowerId = "FID_00001";
                }
                flowerDBContext.FlowerDetails.Add(flowerData);
                flowerDBContext.SaveChanges(); // Use SaveChanges instead of SaveChangesAsync
                return RedirectToAction("Index");
            }
            return View();
        }

        public ActionResult Details(string Id)
        {
            if (Id != null)
            {
                NurseryManagementEntities flowerDBContext = new NurseryManagementEntities();
                var flower = flowerDBContext.FlowerDetails.Where(x => x.FlowerId == Id).FirstOrDefault();
                return View(flower);
            }
            else
            {
                return HttpNotFound();
            }
        }

        public ActionResult Edit(string Id)
        {
            if (Id != null)
            {
                NurseryManagementEntities flowerDBContext = new NurseryManagementEntities();
                var flower = flowerDBContext.FlowerDetails.Where(x => x.FlowerId == Id).FirstOrDefault();
                TempData["Title"] = "Edit";
                return View("AddEdit", flower);

            }
            return View("AddEdit");
        }


        [HttpPost]
        public ActionResult Edit(FlowerDetail flowerData)
        {
            if (ModelState.IsValid)
            {
                NurseryManagementEntities flowerDBContext = new NurseryManagementEntities();
                flowerDBContext.Entry(flowerData).State = System.Data.Entity.EntityState.Modified;
                flowerDBContext.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View();
        }

        public ActionResult Delete(string Id)
        {
            if (Id != null)
            {
                NurseryManagementEntities flowerDBContext = new NurseryManagementEntities();
                var flower = flowerDBContext.FlowerDetails.Where(x => x.FlowerId == Id).FirstOrDefault();
                return View(flower);
            }
            return View();
        }
        
        [HttpPost]
        [ActionName("Delete")]
        public ActionResult DeleteFlower(string Id)
        {
            if (Id != null)
            {
                NurseryManagementEntities flowerDBContext = new NurseryManagementEntities();
                var flower = flowerDBContext.FlowerDetails.Where(x => x.FlowerId == Id).FirstOrDefault();
                flowerDBContext.FlowerDetails.Remove(flower);
                flowerDBContext.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View();
        }
    }
}