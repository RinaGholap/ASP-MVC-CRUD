﻿using NurseryManagementMVC_CRUD.CustomFilter;
using NurseryManagementMVC_CRUD.Filter;
using NurseryManagementMVC_CRUD.Models;
using System;
using System.Data.Entity;
using System.Linq;
using System.Web.Mvc;

namespace Final_Assignment_Rina_Gholap.Controllers
{
    [CustomAuthorizationFilter]
    [UserAuthorizationFilter(AllowedRole = "Admin")]
    public class OrdersController : Controller
    {
        // GET: Orders
        public ActionResult Index()
        {
            NurseryManagementEntities ordersDBContext = new NurseryManagementEntities();
            var ordersList = ordersDBContext.Orders.ToList();
            ViewBag.TotalOrders = ordersList.Count;
            return View(ordersList);
        }

        public ActionResult Order()
        {
            NurseryManagementEntities ordersDBContext = new NurseryManagementEntities();
            var flowerList = ordersDBContext.FlowerDetails.Select(flower => new SelectListItem
            {
                Text = flower.FlowerName,
                Value = flower.FlowerId.ToString()
            }).ToList();
            TempData["FlowerList"] = flowerList;

            var shippingCostsList = ordersDBContext.CostDetails.Select(cost => new SelectListItem
            {
                Text = cost.ShippingCost.ToString(),
                Value = cost.CostId.ToString()
            }).ToList();
            TempData["CostsList"] = shippingCostsList;

            var usersList = ordersDBContext.Users.Select(user => new SelectListItem
            {
                Text = user.UserName,
                Value = user.UserId.ToString()
            }).ToList();
            TempData["UserNameList"] = usersList;
            return View();
        }

        [HttpPost]
        public ActionResult Order(Order orderData)
        {
            if (ModelState.IsValid)
            {
                NurseryManagementEntities ordersDBContext = new NurseryManagementEntities();
                var flowerList = ordersDBContext.FlowerDetails.Where(x => x.FlowerId == orderData.FlowerID).FirstOrDefault();
                var orderDetails = ordersDBContext.Orders.ToList();
                // Get the latest OrderID from the database
                var latestOrder = ordersDBContext.Orders.OrderByDescending(o => o.OrderID).FirstOrDefault();

                if (latestOrder != null)
                {   // Extract the numeric part of the latest OrderID and increment it
                    int latestIdNumericPart = int.Parse(latestOrder.OrderID.Substring(4));
                    orderData.OrderID = "ORD_" + (latestIdNumericPart + 1).ToString("D7"); // Pad with leading zeros
                }
                else
                {   // If there are no existing records, start with "ORD_0000001"
                    orderData.OrderID = "ORD_0000001";
                }

                // Calculate TotalAmount based on Price * Quantity + ShippingCost
                var flowerDetails = ordersDBContext.FlowerDetails.Find(orderData.FlowerID);
                var costDetails = ordersDBContext.CostDetails.Find(orderData.CostId);
                if (flowerDetails != null && costDetails != null)
                {
                    if (flowerDetails.Stock >= orderData.Quantity)
                    {
                        // Sufficient stock available, proceed with the order
                        orderData.TotalAmount = (flowerDetails.Price * orderData.Quantity) + costDetails.ShippingCost;
                        flowerDetails.Stock -= orderData.Quantity;

                        // Update the stock in the database
                        ordersDBContext.Entry(flowerDetails).State = EntityState.Modified;

                        orderData.OrderDate = DateTime.Now.Date;
                        orderData.OrderStatus = "Processing";
                        ordersDBContext.Orders.Add(orderData);
                        ordersDBContext.SaveChanges();
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        // Not enough stock available, handle this case (e.g., show an error message)
                        ModelState.AddModelError("Quantity", "Not enough stock available for this flower.");
                        return RedirectToAction("Index");
                    }
                }
                else
                {   // Handle the case where FlowerID or CostId is invalid
                    return View();
                }
                //flowerList.Stock = flowerList.Stock - orderData.Quantity;
                //ordersDBContext.Entry(flowerList).State = System.Data.Entity.EntityState.Modified;

                //orderData.OrderDate = DateTime.Now.Date;
                //orderData.OrderStatus = "Processing";
                //ordersDBContext.Orders.Add(orderData);
                //ordersDBContext.SaveChanges();
                //return RedirectToAction("Index");
            }
            return View();
        }

        public ActionResult Details(string Id)
        {
            if (Id != null)
            {
                NurseryManagementEntities ordersDBContext = new NurseryManagementEntities();
                var orderDetails = ordersDBContext.Orders.Where(x => x.OrderID == Id).FirstOrDefault();
                return View(orderDetails);
            }
            else
            {
                return HttpNotFound();
            }
        }

        public ActionResult Edit(string Id)
        {
            if (Id != null)
            {
                NurseryManagementEntities ordersDBContext = new NurseryManagementEntities();
                var orderDetail = ordersDBContext.Orders.Where(x => x.OrderID == Id).FirstOrDefault();
                TempData["Title"] = "Edit";

                var flowerList = ordersDBContext.FlowerDetails.Select(flower => new SelectListItem
            {
                Text = flower.FlowerName,
                Value = flower.FlowerId.ToString()
            }).ToList();
            TempData["FlowerList"] = flowerList;

            var shippingCostsList = ordersDBContext.CostDetails.Select(cost => new SelectListItem
            {
                Text = cost.ShippingCost.ToString(),
                Value = cost.CostId.ToString()
            }).ToList();
            TempData["CostsList"] = shippingCostsList;

            var usersList = ordersDBContext.Users.Select(user => new SelectListItem
            {
                Text = user.UserName,
                Value = user.UserId.ToString()
            }).ToList();
            TempData["UserNameList"] = usersList;
                
                return View("Edit", orderDetail);
            }
            return View("Edit");
        }

        [HttpPost]
        public ActionResult Edit(Order orderData)
        {
            if (ModelState.IsValid)
            {
                NurseryManagementEntities ordersDBContext = new NurseryManagementEntities();
                ordersDBContext.Entry(orderData).State = System.Data.Entity.EntityState.Modified;
                ordersDBContext.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View();
        }
        public ActionResult Delete(string Id)
        {
            if (Id != null)
            {
                NurseryManagementEntities ordersDBContext = new NurseryManagementEntities();
                var orderDetail = ordersDBContext.Orders.Where(x => x.OrderID == Id).FirstOrDefault();
                return View(orderDetail);
            }
            return View();
        }

        [HttpPost]
        [ActionName("Delete")]
        public ActionResult DeleteOrder(string Id)
        {
            if (Id != null)
            {
                NurseryManagementEntities ordersDBContext = new NurseryManagementEntities();
                var order = ordersDBContext.Orders.Where(o => o.OrderID == Id).FirstOrDefault();

                if (order != null)
                {   
                    if(order.OrderStatus != "Delivered")
                    {   // Update the OrderStatus to "cancelled"
                        order.OrderStatus = "Cancelled";
                        // Restore stock when an order is canceled
                        var flowerDetails = ordersDBContext.FlowerDetails.Find(order.FlowerID);
                        flowerDetails.Stock += order.Quantity;

                        // Update the stock in the database
                        ordersDBContext.Entry(flowerDetails).State = EntityState.Modified;

                        ordersDBContext.SaveChanges();
                    }
                    else
                    {
                        TempData["InvalidStatusErrorMsg"] = "Order is already Delivered, can not be Cancelled";
                        return RedirectToAction("Index");
                    }                    
                }
                return RedirectToAction("Index");
            }
            return View();
        }

    }
}