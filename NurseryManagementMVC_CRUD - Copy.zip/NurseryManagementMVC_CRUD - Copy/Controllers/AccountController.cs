﻿using NurseryManagementMVC_CRUD.Models;
using System.Linq;
using System.Web.Mvc;
using System.Web.Security;

namespace Final_Assignment_Rina_Gholap.Controllers
{
    public class AccountController : Controller
    {
        // GET: Display the login form.
        public ActionResult Login()
        {
            return View();
        }

        // POST: Process login form submission.
        [HttpPost]
        public ActionResult Login(User user)
        {
            if (ModelState.IsValid)
            {
                NurseryManagementEntities userDBContext = new NurseryManagementEntities();
                // Check if there is a user with the provided username and password.
                var userData = userDBContext.Users.Where(x => x.UserName.ToLower() == user.UserName.ToLower() &&
                                                              x.Password == user.Password).FirstOrDefault();
                if (userData != null)
                {   // Store user information in session and set authentication cookie.
                    Session["UserId"] = userData.UserId;
                    Session["UserName"] = userData.UserName;
                    FormsAuthentication.SetAuthCookie(user.UserName.ToLower(), false);

                    if(userData.Role == "Admin")
                        return RedirectToAction("Index", "Home");
                    else
                        return RedirectToAction("Index", "Nursery");
                }
                else
                {   // Clear session and show an error message for invalid credentials.
                    Session["UserId"] = null;
                    Session["UserName"] = null;
                    Session.Abandon();
                    FormsAuthentication.SignOut();
                    ViewBag.InvalidCredentialsErrorMsg = "Invalid UserName or Password";
                    return View();
                }
            }
            return View();
        }

        // GET: Process logout.
        public ActionResult Logout()
        {   // Clear the session and redirect to the login page.
            Session["UserId"] = null;
            Session["UserName"] = null;
            Session.Abandon();
            return RedirectToAction("Login");
        }

    }
}
