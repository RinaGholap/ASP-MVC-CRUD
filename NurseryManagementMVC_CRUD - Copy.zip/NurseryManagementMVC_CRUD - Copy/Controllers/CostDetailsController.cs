﻿using NurseryManagementMVC_CRUD.CustomFilter;
using NurseryManagementMVC_CRUD.Filter;
using NurseryManagementMVC_CRUD.Models;
using System.Linq;
using System.Web.Mvc;

namespace Final_Assignment_Rina_Gholap.Controllers
{
    [CustomAuthorizationFilter]
    [UserAuthorizationFilter(AllowedRole = "Admin")]
    public class CostDetailsController : Controller
    {
        // GET: CostDetails
        public ActionResult Index()
        {
            NurseryManagementEntities costDetailsDBContext = new NurseryManagementEntities();
            var costDetails = costDetailsDBContext.CostDetails.ToList();
            ViewBag.TotalCostDetails = costDetails.Count;
            return View(costDetails);
        }

        public ActionResult Create()
        {
            NurseryManagementEntities costDetailsDBContext = new NurseryManagementEntities();
            var flowerList = costDetailsDBContext.FlowerDetails.Select(flower => new SelectListItem
            {
                Text = flower.FlowerName,
                Value = flower.FlowerId.ToString()
            }).ToList();
            TempData["FlowerList"] = flowerList;
            TempData["Title"] = "Add";
            return View("AddEdit");
        }

        [HttpPost]
        public ActionResult Create(CostDetail costDetailData)
        {
            if (ModelState.IsValid)
            {
                NurseryManagementEntities costDetailsDBContext = new NurseryManagementEntities();
                var costDetails = costDetailsDBContext.CostDetails.ToList();
                // Get the latest CostId from the database
                var latestCostDetail = costDetailsDBContext.CostDetails.OrderByDescending(c => c.CostId).FirstOrDefault();
                if (latestCostDetail != null)
                {   // Extract the numeric part of the latest CostId and increment it
                    int latestIdNumericPart = int.Parse(latestCostDetail.CostId.Substring(1)); // Start from position 1
                    costDetailData.CostId = "C" + (latestIdNumericPart + 1).ToString("D5"); // Pad with leading zeros
                }
                else
                {   // If there are no existing records, start with "C00001"
                    costDetailData.CostId = "C00001";
                }
                costDetailsDBContext.CostDetails.Add(costDetailData);
                costDetailsDBContext.SaveChanges();
                return RedirectToAction("Index");
            }
            return View();
        }

        public ActionResult Details(string Id)
        {
            if (Id != null)
            {
                NurseryManagementEntities costDetailsDBContext = new NurseryManagementEntities();
                var costDetail = costDetailsDBContext.CostDetails.Where(x => x.CostId == Id).FirstOrDefault();
                return View(costDetail);
            }
            else
            {
                return HttpNotFound();
            }
        }

        public ActionResult Edit(string Id)
        {
            if (Id != null)
            {
                NurseryManagementEntities costDetailsDBContext = new NurseryManagementEntities();
                var costDetail = costDetailsDBContext.CostDetails.Where(x => x.CostId == Id).FirstOrDefault();
                var flowerList = costDetailsDBContext.FlowerDetails.Select(flower => new SelectListItem
                {
                    Text = flower.FlowerName,
                    Value = flower.FlowerId.ToString()
                }).ToList();
                TempData["FlowerList"] = flowerList;
                TempData["PurchaseDate"] = costDetail.PurchaseDate.ToString("yyyy-MM-dd");
                TempData["Title"] = "Edit";
                return View("AddEdit", costDetail);
            }
            return View("AddEdit");
        }

        [HttpPost]
        public ActionResult Edit(CostDetail costDetailData)
        {
            if (ModelState.IsValid)
            {
                NurseryManagementEntities costDetailsDBContext = new NurseryManagementEntities();
                costDetailsDBContext.Entry(costDetailData).State = System.Data.Entity.EntityState.Modified;
                costDetailsDBContext.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View();
        }

        public ActionResult Delete(string Id)
        {
            if (Id != null)
            {
                NurseryManagementEntities costDetailsDBContext = new NurseryManagementEntities();
                var costDetail = costDetailsDBContext.CostDetails.Where(x => x.CostId == Id).FirstOrDefault();
                return View(costDetail);
            }
            return View();
        }

        [HttpPost]
        [ActionName("Delete")]
        public ActionResult DeleteFlower(string Id)
        {
            if (Id != null)
            {
                NurseryManagementEntities costDetailsDBContext = new NurseryManagementEntities();
                var costDetail = costDetailsDBContext.CostDetails.Where(x => x.CostId == Id).FirstOrDefault();
                costDetailsDBContext.CostDetails.Remove(costDetail);
                costDetailsDBContext.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View();
        }
    }
}