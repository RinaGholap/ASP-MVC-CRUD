﻿using NurseryManagementMVC_CRUD.CustomFilter;
using NurseryManagementMVC_CRUD.Filter;
using System.Web.Mvc;

namespace NurseryManagementMVC_CRUD.Controllers
{
    public class HomeController : Controller
    {
        [CustomAuthorizationFilter]
        [UserAuthorizationFilter(AllowedRole = "Admin")]
        public ActionResult Index()
        {
            return View();
        }
    }
}