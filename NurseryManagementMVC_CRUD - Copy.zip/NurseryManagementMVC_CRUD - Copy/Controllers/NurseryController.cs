﻿using NurseryManagementMVC_CRUD.CustomFilter;
using NurseryManagementMVC_CRUD.Filter;
using NurseryManagementMVC_CRUD.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.Linq;
using System.Web.Mvc;
using System.Web.UI.WebControls.WebParts;

namespace Final_Assignment_Rina_Gholap.Controllers
{
    [CustomAuthorizationFilter]
    [AdminAuthorizationFilter(AllowedRole = "User")]
    public class NurseryController : Controller
    {
        private NurseryManagementEntities dbContext = new NurseryManagementEntities();
        // GET: Nursery
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult FloweringPlants()
        {
            NurseryManagementEntities flowerDBContext = new NurseryManagementEntities();
            var flowersList = flowerDBContext.FlowerDetails.ToList();
            ViewBag.TotalFlowers = flowersList.Count;
            return View(flowersList);
        }

        public ActionResult FlowersList()
        {
            NurseryManagementEntities flowerDBContext = new NurseryManagementEntities();
            var flowersList = flowerDBContext.FlowerDetails.ToList();
            ViewBag.TotalFlowers = flowersList.Count;
            return View(flowersList);
        }

        public ActionResult FlowerDetails(string Id)
        {
            if (Id != null)
            {
                NurseryManagementEntities flowerDBContext = new NurseryManagementEntities();
                var flower = flowerDBContext.FlowerDetails.Where(x => x.FlowerId == Id).FirstOrDefault();
                return View(flower);
            }
            else
            {
                return HttpNotFound();
            }
        }

        public ActionResult Order(string Id)
        {
            NurseryManagementEntities ordersDBContext = new NurseryManagementEntities();
            var flowerDetails = ordersDBContext.FlowerDetails.Find(Id);

            if (flowerDetails.Stock > 1)
            {
                TempData["flowerId"] = Id;
                ViewBag.flowerName = flowerDetails.FlowerName;
                TempData["FlowerPrice"] = flowerDetails.Price;

                var shippingCost = ordersDBContext.CostDetails.Where(x => x.FlowerID == Id).FirstOrDefault();
                TempData["costId"] = shippingCost.CostId;
                ViewBag.shippingCost = shippingCost.ShippingCost;

                //var flowerList = ordersDBContext.FlowerDetails.Select(x => new SelectListItem
                //{
                //    Text = x.FlowerName,
                //    Value = x.FlowerId.ToString()
                //}).ToList();
                //TempData["FlowerList"] = flowerList;

                var shippingCostsList = ordersDBContext.CostDetails.Select(cost => new SelectListItem
                {
                    Text = cost.ShippingCost.ToString(),
                    Value = cost.CostId.ToString(),
                }).ToList();
                TempData["CostsList"] = shippingCostsList;

                //var usersList = ordersDBContext.Users.Select(user => new SelectListItem
                //{
                //    Text = user.UserName,
                //    Value = user.UserId.ToString(),
                //}).ToList();
                //TempData["UserNameList"] = usersList;
                //ViewBag.SelectedFlowerId = Id;

                //NurseryManagementEntities costDetailsDBContext = new NurseryManagementEntities();
                //var costDetail = costDetailsDBContext.CostDetails.Where(x => x.FlowerID == flowerId).FirstOrDefault();
                //if (costDetail != null)
                //{
                //    // Assign the ShippingCost value to the model property
                //    ViewBag.ShippingCost = costDetail.ShippingCost.ToString();
                //}

                //NurseryManagementEntities costDetailsDBContext = new NurseryManagementEntities();
                //var costDetail = costDetailsDBContext.CostDetails.Where(x => x.FlowerID == flowerId).FirstOrDefault();

                //// Create a SelectList for the CostId dropdown
                //var costList = new SelectList(costDetailsDBContext.CostDetails, "CostId", "ShippingCost", costDetail.CostId);

                //ViewBag.CostList = costList;
                return View("Checkout");
            }
            else
            {
                // Not enough stock available, handle this case (e.g., show an error message)                        
                TempData["InvalidStatusErrorMsg"] = "Not enough stock available for this flower.";
                return RedirectToAction("FlowersList");
            }
        }

        [HttpPost]
        public ActionResult Order(Order orderData)
        {
            if (ModelState.IsValid)
            {
                orderData.FlowerID = TempData["flowerId"].ToString();
                orderData.CostId = TempData["costId"].ToString();

                NurseryManagementEntities ordersDBContext = new NurseryManagementEntities();
                var flowerDetails = ordersDBContext.FlowerDetails.Find(orderData.FlowerID);
                var costDetails = ordersDBContext.CostDetails.Find(orderData.CostId);

                if (flowerDetails != null && costDetails != null)
                {
                    if (flowerDetails.Stock >= orderData.Quantity)
                    {
                        // Sufficient stock available, proceed with the order

                        //var flowerList = ordersDBContext.FlowerDetails.Where(x => x.FlowerId == orderData.FlowerID).FirstOrDefault();
                       // var orderDetails = ordersDBContext.Orders.ToList();

                        // Get the latest OrderID from the database
                        var latestOrder = ordersDBContext.Orders.OrderByDescending(o => o.OrderID).FirstOrDefault();

                        if (latestOrder != null)
                        {   // Extract the numeric part of the latest OrderID and increment it
                            int latestIdNumericPart = int.Parse(latestOrder.OrderID.Substring(4));
                            orderData.OrderID = "ORD_" + (latestIdNumericPart + 1).ToString("D7"); // Pad with leading zeros
                        }
                        else
                        {   // If there are no existing records, start with "ORD_0000001"
                            orderData.OrderID = "ORD_0000001";
                        }

                        // Calculate TotalAmount based on Price * Quantity + ShippingCost
                        orderData.TotalAmount = (flowerDetails.Price * orderData.Quantity) + costDetails.ShippingCost;

                        flowerDetails.Stock -= orderData.Quantity;
                        // Update the stock in the database
                        ordersDBContext.Entry(flowerDetails).State = EntityState.Modified;

                        orderData.OrderDate = DateTime.Now.Date;
                        orderData.OrderStatus = "Processing";
                        orderData.UserId = Session["UserId"].ToString();
                        ordersDBContext.Orders.Add(orderData);
                        ordersDBContext.SaveChanges();
                        return RedirectToAction("MyOrders");
                    }
                    else
                    {
                        // Not enough stock available, handle this case (e.g., show an error message)                        
                        TempData["InvalidStatusErrorMsg"] = "Not enough stock available for this flower.";
                        return RedirectToAction("FlowersList");
                    }
                }
                else
                {   // Handle the case where FlowerID or CostId is invalid
                    return RedirectToAction("FlowersList");
                }
                //flowerList.Stock = flowerList.Stock - orderData.Quantity;
                //ordersDBContext.Entry(flowerList).State = System.Data.Entity.EntityState.Modified;


                //orderData.OrderDate = DateTime.Now.Date;
                //orderData.OrderStatus = "Processing";
                //orderData.UserId = Session["UserId"].ToString();
                //ordersDBContext.Orders.Add(orderData);
                //ordersDBContext.SaveChanges();
                //return RedirectToAction("Index");
            }
            return View();
        }

        private List<CartItem> GetCart()
        {
            // Retrieve cart from session or create a new one
            var cart = Session["Cart"] as List<CartItem>;
            if (cart == null)
            {
                cart = new List<CartItem>();
                Session["Cart"] = cart;
            }
            return cart;
        }

        public ActionResult AddToCart(string flowerId)
        {

            //NurseryManagementEntities flowerDBContext = new NurseryManagementEntities();   
            //var flower = flowerDBContext.FlowerDetails.Find(flowerId);
            //if (flower != null)
            //{
            //    var cart = GetCart();

            //    // Check if the flower is already in the cart
            //    var existingItem = cart.FirstOrDefault(item => item.FlowerId == flowerId);

            //    if (existingItem != null)
            //    {
            //        // Increment quantity if flower is already in the cart
            //        existingItem.Quantity++;
            //    }
            //    else
            //    {
            //        // Add new item to the cart
            //        cart.Add(new CartItem
            //        {
            //            FlowerId = flower.FlowerId,
            //            Quantity = 1,
            //            Price = flower.Price
            //        });
            //    }
            //}

            //return RedirectToAction("FloweringPlants");

            // Assuming you have a user authentication system, retrieve the user's ID
            var userId = Session["UserId"].ToString(); // Adjust this based on your authentication system

            // Check if the user has an existing cart or create a new one
            var cart = dbContext.Carts.FirstOrDefault(c => c.UserId == userId);
            if (cart == null)
            {
                // Extract the numeric part of the latest CartItemId and increment it
                int latestCartItemNumericPart;
                var latestCartItem = dbContext.CartItems.OrderByDescending(ci => ci.CartItemId).FirstOrDefault();

                if (latestCartItem != null && int.TryParse(latestCartItem.CartItemId.Substring(3), out latestCartItemNumericPart))
                {
                    // Increment the numeric part
                    latestCartItemNumericPart += 1;
                }
                else
                {
                    // Handle the case where the parsing fails, perhaps set a default value
                    latestCartItemNumericPart = 1; // You can set any default value here
                }

                //// Get the latest CartId from the database
                //var latestCart = dbContext.Carts.OrderByDescending(c => c.CartId).FirstOrDefault();

                //int latestCartNumericPart = 1;
                //if (latestCart != null)
                //{
                //    // Extract the numeric part of the latest CartId and increment it
                //    latestCartNumericPart = int.Parse(latestCart.CartId.Substring(3)) + 1;
                //}

                cart = new Cart
                {
                    CartId = "CI_" + latestCartItemNumericPart.ToString("D6"), // Pad with leading zeros
                    UserId = userId,
                    CreationDate = DateTime.Now
                };

                dbContext.Carts.Add(cart);
                dbContext.SaveChanges();
            }

            // Check if the flower is already in the cart
            var existingItem = dbContext.CartItems.FirstOrDefault(item => item.CartId == cart.CartId && item.FlowerId == flowerId);

            if (existingItem != null)
            {
                // Increment quantity if the flower is already in the cart
                existingItem.Quantity++;
                // Save changes to the database
                dbContext.SaveChanges();
            }
            else
            {
                // Add a new item to the cart
                var flower = dbContext.FlowerDetails.Find(flowerId);
                if (flower != null)
                {
                    // Get the latest CartItemId from the database
                    int latestCartItemNumericPart;
                    var latestCartItem = dbContext.CartItems.OrderByDescending(ci => ci.CartItemId).FirstOrDefault();

                    if (latestCartItem != null)
                    {
                        //Extract the numeric part of the latest FlowerId and increment it
                        latestCartItemNumericPart = int.Parse(latestCartItem.CartItemId.Substring(4));
                        // Increment the numeric part
                        latestCartItemNumericPart += 1;
                    }
                    else
                    {
                        // Handle the case where the parsing fails, perhaps set a default value
                        latestCartItemNumericPart = 1; // You can set any default value here
                    }

                    // Retrieve the cost details for the flower
                    var costDetails = dbContext.CostDetails.FirstOrDefault(cd => cd.FlowerID == flowerId);

                    var newCartItem = new CartItem
                    {
                        CartItemId = "CID_" + latestCartItemNumericPart.ToString("D6"), // Pad with leading zeros
                        CartId = cart.CartId,
                        FlowerId = flower.FlowerId,
                        Quantity = 1,
                        Price = flower.Price,
                        CostId = costDetails?.CostId // Assign CostId if costDetails is not null
                    };

                    dbContext.CartItems.Add(newCartItem);
                    dbContext.SaveChanges();
                }
            }

            // Redirect to the FloweringPlants view
            return RedirectToAction("FloweringPlants");
        }

        public ActionResult ViewCart()
        {
            // Assuming you have a user authentication system, retrieve the user's ID
            var userId = Session["UserId"].ToString(); // Adjust this based on your authentication system

            // Get the cart for the logged-in user
            var cart = dbContext.Carts
                .Include(c => c.CartItems.Select(ci => ci.FlowerDetail)) // Include Flower navigation property
                .FirstOrDefault(c => c.UserId == userId);

            // Check if the cart is not null and has cart items
            if (cart != null && cart.CartItems != null)
            {
                // Pass the cart items to the view
                return View(cart.CartItems);
            }

            // If the cart is null or has no items, return an empty view or handle accordingly
            return View(new List<CartItem>());
        }

        public ActionResult IncrementQuantity(string cartItemId)
        {
            UpdateQuantity(cartItemId, 1);
            return RedirectToAction("ViewCart");
        }

        public ActionResult DecrementQuantity(string cartItemId)
        {
            UpdateQuantity(cartItemId, -1);
            return RedirectToAction("ViewCart");
        }

        private void UpdateQuantity(string cartItemId, int change)
        {
            var cartItem = dbContext.CartItems.FirstOrDefault(ci => ci.CartItemId == cartItemId);

            if (cartItem != null)
            {
                cartItem.Quantity += change;
                dbContext.SaveChanges();
            }
        }


        [HttpGet]
        public ActionResult PlaceOrder()
        {
            var cartItems = GetCart(); // Implement GetCart() method to retrieve cart items
            return View(cartItems);
        }




        public ActionResult MyOrders()
        {
            NurseryManagementEntities ordersDBContext = new NurseryManagementEntities();
            // Get the user's ID from the session
            string userId = Session["UserId"].ToString();
            // Retrieve orders for the specific user
            var userOrders = ordersDBContext.Orders.Where(o => o.UserId == userId).ToList();
            ViewBag.TotalOrders = userOrders.Count;
            return View(userOrders);
        }

        public ActionResult OrderDetails(string Id)
        {
            if (Id != null)
            {
                NurseryManagementEntities ordersDBContext = new NurseryManagementEntities();
                var orderDetails = ordersDBContext.Orders.Where(x => x.OrderID == Id).FirstOrDefault();
                return View(orderDetails);
            }
            else
            {
                return HttpNotFound();
            }
        }

        public ActionResult CancelOrder(string Id)
        {
            if (Id != null)
            {
                NurseryManagementEntities ordersDBContext = new NurseryManagementEntities();
                var orderDetail = ordersDBContext.Orders.Where(x => x.OrderID == Id).FirstOrDefault();
                return View(orderDetail);
            }
            return View();
        }

        [HttpPost]
        [ActionName("CancelOrder")]
        public ActionResult CancelOrderDetails(string Id)
        {
            if (Id != null)
            {
                NurseryManagementEntities ordersDBContext = new NurseryManagementEntities();
                var order = ordersDBContext.Orders.Where(o => o.OrderID == Id).FirstOrDefault();

                if (order != null)
                {
                    if (order.OrderStatus != "Delivered")
                    {
                        // Update the OrderStatus to "cancelled"
                        order.OrderStatus = "Cancelled";
                        // Restore stock when an order is canceled
                        var flowerDetails = ordersDBContext.FlowerDetails.Find(order.FlowerID);
                        flowerDetails.Stock += order.Quantity;

                        // Update the stock in the database
                        ordersDBContext.Entry(flowerDetails).State = EntityState.Modified;

                        ordersDBContext.SaveChanges();
                    }
                    else
                    {
                        TempData["InvalidStatusErrorMsg"] = "Order is already Delivered, can not be Cancelled";
                        return RedirectToAction("MyOrders");
                    }
                }
                return RedirectToAction("MyOrders");
            }
            return View();
        }

    }
}