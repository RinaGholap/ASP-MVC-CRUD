﻿using NurseryManagementMVC_CRUD.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NurseryManagementMVC_CRUD.Controllers
{
    public class CartController : Controller
    {
        private NurseryManagementEntities dbContext = new NurseryManagementEntities();

        // GET: Cart
        public ActionResult Index()
        {
            return View();
        }

        private List<CartItem> GetCart()
        {
            // Retrieve cart from session or create a new one
            var cart = Session["Cart"] as List<CartItem>;
            if (cart == null)
            {
                cart = new List<CartItem>();
                Session["Cart"] = cart;
            }
            return cart;
        }

        public ActionResult AddToCart(string flowerId)
        {

            //NurseryManagementEntities flowerDBContext = new NurseryManagementEntities();   
            //var flower = flowerDBContext.FlowerDetails.Find(flowerId);
            //if (flower != null)
            //{
            //    var cart = GetCart();

            //    // Check if the flower is already in the cart
            //    var existingItem = cart.FirstOrDefault(item => item.FlowerId == flowerId);

            //    if (existingItem != null)
            //    {
            //        // Increment quantity if flower is already in the cart
            //        existingItem.Quantity++;
            //    }
            //    else
            //    {
            //        // Add new item to the cart
            //        cart.Add(new CartItem
            //        {
            //            FlowerId = flower.FlowerId,
            //            Quantity = 1,
            //            Price = flower.Price
            //        });
            //    }
            //}

            //return RedirectToAction("FloweringPlants");

            // Assuming you have a user authentication system, retrieve the user's ID
            var userId = Session["UserId"].ToString();// Adjust this based on your authentication system

            // Check if the user has an existing cart or create a new one
            var cart = dbContext.Carts.FirstOrDefault(c => c.UserId == userId);
            if (cart == null)
            {
                cart = new Cart
                {
                    CartId = Guid.NewGuid().ToString(),
                    UserId = userId,
                    CreationDate = DateTime.Now
                };

                dbContext.Carts.Add(cart);
                dbContext.SaveChanges();
            }

            // Check if the flower is already in the cart
            var existingItem = dbContext.CartItems.FirstOrDefault(item => item.CartId == cart.CartId && item.FlowerId == flowerId);

            if (existingItem != null)
            {
                // Increment quantity if the flower is already in the cart
                existingItem.Quantity++;
            }
            else
            {
                // Add a new item to the cart
                var flower = dbContext.FlowerDetails.Find(flowerId);
                if (flower != null)
                {
                    var costDetails = dbContext.CostDetails.FirstOrDefault(); // You may need to adjust this based on your logic
                    var newCartItem = new CartItem
                    {
                        CartItemId = Guid.NewGuid().ToString(),
                        CartId = cart.CartId,
                        FlowerId = flower.FlowerId,
                        Quantity = 1,
                        Price = flower.Price,
                        CostId = costDetails.CostId // Again, adjust this based on your logic
                    };

                    dbContext.CartItems.Add(newCartItem);
                    dbContext.SaveChanges();
                }
            }

            // Redirect to the FloweringPlants view
            return RedirectToAction("FloweringPlants");
        }

        public ActionResult ViewCart()
        {
            var cart = GetCart();
            return View(cart);
        }
    }
}