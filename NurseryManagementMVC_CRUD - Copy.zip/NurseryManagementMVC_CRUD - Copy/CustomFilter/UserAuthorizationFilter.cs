﻿using NurseryManagementMVC_CRUD.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace NurseryManagementMVC_CRUD.CustomFilter
{
    public class UserAuthorizationFilter : ActionFilterAttribute, IActionFilter, IAuthorizationFilter
    {
        public string AllowedRole { get; set; }

        public void OnAuthorization(AuthorizationContext filterContext)
        {

            NurseryManagementEntities UsersDBContext = new NurseryManagementEntities();
            var session = filterContext.HttpContext.Session;
            string userName = filterContext.HttpContext.Session["UserName"] as string;
            var userData = UsersDBContext.Users.Where(x => x.UserName.ToLower() == userName).FirstOrDefault();

            var user = filterContext.HttpContext.User;
            if (session["UserName"] != null)
            {
                if (userData.Role != "Admin")
                {
                    if (user.Identity.IsAuthenticated && user.IsInRole(AllowedRole))
                    {
                        filterContext.Result = new RedirectToRouteResult(
                                            new RouteValueDictionary { { "controller", "Nursery" }, { "action", "Index" } });
                    }
                    else
                    {
                        // User doesn't have the allowed role, so you can handle unauthorized access here.
                        filterContext.Result = new HttpStatusCodeResult(HttpStatusCode.Forbidden); // Or redirect to an error page, as needed.
                    }
                }
            }
            else
            {
                filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary { { "controller", "Account" }, { "action", "Login" } });
            }                

        }
    }
}