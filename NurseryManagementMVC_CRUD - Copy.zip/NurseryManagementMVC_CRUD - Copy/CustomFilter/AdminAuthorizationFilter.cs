﻿using NurseryManagementMVC_CRUD.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace NurseryManagementMVC_CRUD.CustomFilter
{
    public class AdminAuthorizationFilter : ActionFilterAttribute, IActionFilter, IAuthorizationFilter
    {
        public string AllowedRole { get; set; }

        public void OnAuthorization(AuthorizationContext filterContext)
        {
            NurseryManagementEntities UsersDBContext = new NurseryManagementEntities();
            var session = filterContext.HttpContext.Session;
            string userName = filterContext.HttpContext.Session["UserName"] as string;
            var userData = UsersDBContext.Users.Where(x => x.UserName.ToLower() == userName).FirstOrDefault();

            var user = filterContext.HttpContext.User;
            if (session["UserName"] != null)
            {
                if (userData.Role != "User")
                {
                    if (user.Identity.IsAuthenticated && user.IsInRole(AllowedRole))
                    {
                        filterContext.Result = new RedirectToRouteResult(
                                            new RouteValueDictionary { { "controller", "Home" }, { "action", "Index" } });
                    }
                    else
                    {
                        // Or redirect to an error page, as needed.
                        filterContext.Result = new HttpStatusCodeResult(HttpStatusCode.Forbidden);
                    }
                }
            }
            else
            {
                filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary { { "controller", "Account" }, { "action", "Login" } });
            }                

        }
    }
}