﻿using NurseryManagementMVC_CRUD.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace NurseryManagementMVC_CRUD.Filter
{
    // Custom authorization filter to ensure user authentication.
    public class CustomAuthorizationFilter : ActionFilterAttribute, IActionFilter
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            //NurseryManagementEntities userDBContext = new NurseryManagementEntities();
            var session = filterContext.HttpContext.Session;
            // Check if the user is not authenticated and redirect to the login page if necessary.

            //var userData = userDBContext.Users.Where(x => x.UserId == session["UserId"]).FirstOrDefault();

            if (session == null || (session != null && session["UserName"] == null)  )
            {
                filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary { { "controller", "Account" }, { "action", "Login" } });
            }
            //else if (userData.Role == "User")
            //{
            //    filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary { { "controller", "Account" }, { "action", "Login" } });
            //}
            base.OnActionExecuting(filterContext);
        }
    }
}